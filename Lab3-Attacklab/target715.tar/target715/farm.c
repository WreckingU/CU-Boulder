/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_300()
{
    return 3281031248U;
}

unsigned getval_192()
{
    return 2425995864U;
}

unsigned getval_157()
{
    return 2428995912U;
}

unsigned getval_365()
{
    return 3284633928U;
}

void setval_198(unsigned *p)
{
    *p = 2093191256U;
}

void setval_463(unsigned *p)
{
    *p = 2421745845U;
}

void setval_387(unsigned *p)
{
    *p = 3267856712U;
}

unsigned getval_449()
{
    return 2428995656U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_494(unsigned x)
{
    return x + 3221280393U;
}

unsigned addval_435(unsigned x)
{
    return x + 3525886345U;
}

unsigned getval_337()
{
    return 3526937241U;
}

void setval_443(unsigned *p)
{
    *p = 3286273352U;
}

unsigned getval_252()
{
    return 683923081U;
}

unsigned getval_238()
{
    return 2430634312U;
}

void setval_350(unsigned *p)
{
    *p = 3375415689U;
}

void setval_228(unsigned *p)
{
    *p = 3523794569U;
}

unsigned getval_427()
{
    return 3682910665U;
}

void setval_319(unsigned *p)
{
    *p = 3286272328U;
}

unsigned getval_497()
{
    return 2497087761U;
}

unsigned getval_419()
{
    return 3353381192U;
}

unsigned getval_439()
{
    return 3767077084U;
}

void setval_296(unsigned *p)
{
    *p = 2429208869U;
}

unsigned getval_459()
{
    return 3225995913U;
}

unsigned addval_471(unsigned x)
{
    return x + 3221804553U;
}

unsigned getval_389()
{
    return 2425405833U;
}

unsigned getval_251()
{
    return 3246973291U;
}

unsigned getval_218()
{
    return 3767101663U;
}

unsigned addval_323(unsigned x)
{
    return x + 2496301337U;
}

unsigned addval_477(unsigned x)
{
    return x + 2425667977U;
}

unsigned addval_178(unsigned x)
{
    return x + 3529561737U;
}

void setval_466(unsigned *p)
{
    *p = 3224950408U;
}

unsigned getval_442()
{
    return 2425408137U;
}

unsigned getval_109()
{
    return 3353381192U;
}

unsigned getval_326()
{
    return 2425408139U;
}

unsigned addval_225(unsigned x)
{
    return x + 3525362089U;
}

unsigned getval_164()
{
    return 3286272344U;
}

unsigned getval_399()
{
    return 3523791513U;
}

void setval_362(unsigned *p)
{
    *p = 3525364361U;
}

unsigned getval_316()
{
    return 3375945225U;
}

void setval_470(unsigned *p)
{
    *p = 3224945033U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
